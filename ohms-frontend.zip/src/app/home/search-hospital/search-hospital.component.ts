import { Component, OnInit } from "@angular/core";
import { Hospital } from "src/app/hospital/hospital";
import { HospitalService } from "src/app/services/hospital.service";

@Component({
  selector: "app-search-hospital",
  templateUrl: "./search-hospital.component.html",
  styleUrls: ["./search-hospital.component.css"],
})
export class SearchHospitalComponent implements OnInit {
  noresult = 1;
  keyword = "";
  hospitallist: Hospital[] = [];
  constructor(private _hospitalService: HospitalService) {}

  ngOnInit(): void {
    this.submitSearch("");
  }
  submitSearch(keyword: any) {
    console.log(keyword);
    this._hospitalService.getHospitalList(keyword).subscribe(
      (response: any) => {
        console.log("HospitalList response", response);

        this.hospitallist = response;
        if (this.hospitallist == null) {
          this.noresult = 0;
        } else this.noresult = 1;
      },
      (error: any) => {
        this.noresult = 0;

        console.log(error);
      }
    );
  }
  clearSearch() {
    this.keyword = "";
    this.submitSearch(this.keyword);
  }
}
