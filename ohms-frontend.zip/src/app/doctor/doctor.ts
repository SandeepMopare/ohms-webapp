export interface Doctor {
  drId?: number;
  drName?: string;
  drSpec?: string;
  drEmail?: string;
  drMobile?:string,
  drUsername?:string,
  drPassword?:string,
  drStatus?:string,
  hspId?:number
}
