import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { Hospital } from "src/app/hospital/hospital";
import { DoctorService } from "src/app/services/doctor.service";
import { HospitalService } from "src/app/services/hospital.service";
import { SessionService } from "src/app/services/session.service";
import { PatientAccount } from "../patient.interface";

@Component({
  selector: "app-bookappointment",
  templateUrl: "./bookappointment.component.html",
  styleUrls: ["./bookappointment.component.css"],
})
export class BookappointmentComponent implements OnInit {
  HSPLIST = 1;
  hspList: Hospital[] = [];
  patient: PatientAccount = {};
  constructor(
    private _sessionService: SessionService,
    private _hospitalService: HospitalService,
    private _doctorService: DoctorService,
    private router: Router
  ) {}

  ngOnInit(): void {
    if (this._sessionService.isPatientLoggedIn()) {
      var session = this._sessionService.getPatientSession();
      if (session) {
        this.patient = JSON.parse(session);
        this.getHspList(this.patient.ptId);
      }
    }
  }
  logPatientOut() {
    this._sessionService.logOutPatient();
  }

  getHspList(ptid: any) {
    this._hospitalService.getHspList(ptid).subscribe((response: any) => {
      console.log("HospitalList response", response);

      this.hspList = response;
    });
  }

  doctorList(hspId: any) {
    this.router.navigateByUrl("/doctorList?hspId="+hspId);
    // this._doctorService.getDoctorList(ptId).subscribe((response: any) => {
    //   console.log("HospitalList response", response);
    //   this.hspList = response;

    // });
  }
}
