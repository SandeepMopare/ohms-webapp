import { Component, OnInit } from "@angular/core";
import { DoctorService } from "src/app/services/doctor.service";
import { SessionService } from "src/app/services/session.service";
import { PatientAccount } from "../../patient.interface";
import { Doctor } from "../../../doctor/doctor";

@Component({
  selector: "app-doctorlist",
  templateUrl: "./doctorlist.component.html",
  styleUrls: ["./doctorlist.component.css"],
})
export class DoctorlistComponent implements OnInit {
  b = 3;
  drList: Doctor={};
  DRLIST: number = 1;
  patient: PatientAccount = {};
  constructor(
    private _sessionService: SessionService,
    private _doctorService: DoctorService
  ) {}

  ngOnInit(): void {
    if (this._sessionService.isPatientLoggedIn()) {
      var session = this._sessionService.getPatientSession();
      if (session) {
        this.patient = JSON.parse(session);
      }
    }
  }
}
