import { Injectable } from "@angular/core";
import { Hospital } from "../hospital/hospital";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Observable } from "rxjs";
import { ROOT_API_ENDPOINT } from "./constants";

@Injectable({
  providedIn: "root",
})
export class HospitalService {
  private _apiEndpoint = ROOT_API_ENDPOINT;

  private _hospitalList = "hospitalList";

  private _getHospitalListUrl = this._apiEndpoint + this._hospitalList;

  constructor(private http: HttpClient) {}

  public getHospitalList(keyword: any): Observable<Hospital> {
    const header = new HttpHeaders();
    header.set("Content-Type", "application/json; charser=utf-8");

    const params = new HttpParams();
    params.set("keyword", keyword);
    console.log(typeof(keyword));

    return this.http.get<Hospital>(this._getHospitalListUrl+`?keyword=${keyword}`)
  }

  public getHspList(ptid:number): Observable<Hospital> {
    const header = new HttpHeaders();
    header.set("Content-Type", "application/json; charser=utf-8");

    const params = new HttpParams();
    params.set("ptid", ptid);
    console.log(typeof(ptid));

    return this.http.get<Hospital>(this._getHospitalListUrl+`?ptid=${ptid}`)
  }
  
}
