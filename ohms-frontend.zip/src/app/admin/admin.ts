export interface AdminAuthLoginInterface {
  adminusername?: string;
  adminpassword?: string;
}
