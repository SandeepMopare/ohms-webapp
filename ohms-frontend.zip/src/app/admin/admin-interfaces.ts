export interface Hospital {
    hspId?: string;
    hspName?: string;
    hspAdd?: string;
}