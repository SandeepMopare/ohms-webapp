import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-add-hospital',
  templateUrl: './admin-add-hospital.component.html',
  styleUrls: ['./admin-add-hospital.component.css']
})
export class AdminAddHospitalComponent implements OnInit {
  hspReg = 3;
  constructor() { }

  ngOnInit(): void {
  }

}
