export interface Hospital {
    hspId: number;
    hspAdd: string;
    hspBNo: number;
    hspName: string;
    hsp_password: string;
    hsp_username: string;
    imageUrl?: string;
}
