import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-hospital-login",
  templateUrl: "./hospital-login.component.html",
  styleUrls: ["./hospital-login.component.css"],
})
export class HospitalLoginComponent implements OnInit {
  HspLogFail = 2;
  constructor() {}

  ngOnInit(): void {}
}
