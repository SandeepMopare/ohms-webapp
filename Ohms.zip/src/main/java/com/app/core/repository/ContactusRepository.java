package com.app.core.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.core.entity.Contactus;

public interface ContactusRepository extends JpaRepository<Contactus, Integer>{

}
