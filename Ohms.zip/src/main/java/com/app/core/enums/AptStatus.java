package com.app.core.enums;

public enum AptStatus {

	BOOKED,
	CONFIRMED,
	CANCELLED,
	CLOSED
	
}
