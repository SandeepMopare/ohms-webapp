package com.app.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OhmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(OhmsApplication.class, args);
	}

}
